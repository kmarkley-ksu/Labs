public class Stock 
{
	//Declaring class variables:
	String name, symbol;
	double currentPrice, previousClosingPrice;
	//End declaring class variables
	
	public Stock(String name, String symbol)
	{
		
	}
	
	public String GetName()
	{
		return this.name;
	}
}
